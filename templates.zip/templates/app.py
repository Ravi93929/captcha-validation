from flask import Flask, render_template, request, session, redirect, url_for
import random
import string

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

def generate_captcha():
    # Generate a random string of 6 alphanumeric characters
    return ''.join(random.choices(string.ascii_letters + string.digits, k=6))

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_input = request.form.get('captcha_input')
        generated_captcha = session.get('captcha')

        # Validate the user input
        if user_input == generated_captcha:
            return "Captcha Verified Successfully!"
        else:
            return "Invalid Captcha. Try Again."

    # Generate a new captcha and save it in the session
    session['captcha'] = generate_captcha()
    return render_template('index.html', captcha=session['captcha'])

if __name__ == '__main__':
    app.run(debug=True)